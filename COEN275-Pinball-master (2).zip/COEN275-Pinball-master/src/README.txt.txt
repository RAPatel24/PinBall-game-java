Name: Terry Shih, Aayushi Mehta, Priyanka Advani, Ruchiben Patel
JDK Used: Oracle Version 8.0.1310.11
IDE Used: Eclipse Neon.3 Release (4.6.3)
Main File: Main.java
How to Run: Merely run the main function in Main.java and the program will start